﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Roo.Data
{
    public class ModelFieldValidator
    {
        public ModelFieldValidator(ValidateType validateType, string message)
        {
            this.ValidateType = validateType;
            this.Message = message;
        }

        public ValidateType ValidateType { get; set; }
        public string Message { get; set; }

    }
}
