﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Roo.Data
{
    public interface ISqlBuilder
    {
        string ConnectionString();

        string Select(object data,string where, string orderBy, int count, int start);
        string InsertInto(object data);
        string Update(object data);
        string Delete(object data);
        string CreateTable(Type type);
        string Count(Type type);
    }
}
