﻿using Roo.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Roo.CMS
{
    /// <summary>
    /// 代表内容管理系统信息
    /// </summary>
    public class CMSInfo : ProductionInfo
    {
        public CMSInfo()
        {
            
        }
    }
}
