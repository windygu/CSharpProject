﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Roo.CMS
{
    /// <summary>
    /// 应用信息
    /// </summary>
    public class AppInfo
    {
        public string Name { get; set; }
        public string Title { get; set; }
        public string Url { get; set; }
        public string Icon { get; set; }
        public string WorkDir { get; set; }
    }
}
