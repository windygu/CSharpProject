﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Roo.Data;

namespace Roo.CMS
{
    [DataObject("ArticleTag", "TagName")]
    public class ArticleTag
    {
        [DataField("NVARCHAR(50)", IsPrimary = true)]
        public string TagName { get; set; }

        [DataField("NVARCHAR(50)")]
        public string TTitle { get; set; }
    }
}
